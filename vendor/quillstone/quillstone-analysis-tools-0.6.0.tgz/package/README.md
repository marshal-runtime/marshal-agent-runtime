# `@quillstone/analysis-tools`

Harness-neutral graph analysis services used by Quillstone code intelligence.
The package turns an `AnalysisSnapshot` into bounded query, context, impact,
trace, change-detection, mapping, shape-check, rename-planning, and guarded
Cypher operations.

## Integration boundary

`AnalysisService` receives the graph snapshot, optional search/diff/rename/Cypher
and PDG ports, and an `AnalysisPolicy`. Raw storage, repository mutation, and
host authorization remain outside this package. Cypher is disabled unless the
policy explicitly enables it, and rename applies changes only through an
injected port.

Default Runtime code intelligence reaches these operations through
`@marshal/agent-runtime-code-intelligence`; most hosts should use that service
rather than construct analysis snapshots directly.

## Development

This is a Runtime workspace package, not a documented standalone registry
install.

```powershell
pnpm --filter @quillstone/analysis-tools build
pnpm --filter @quillstone/analysis-tools typecheck
```
