# `@quillstone/communities-processes`

Deterministic community detection and execution-process extraction for a
validated Quillstone analysis graph.

## Integration boundary

`analyzeCommunitiesAndProcesses()` validates the supplied graph, detects
communities, extracts bounded process traces, and returns frozen results.
Separate projection helpers produce cluster and process resource shapes for
code-intelligence adapters. Repository scanning, parsing, persistence, and UI
presentation are handled by other packages.

The default Runtime indexing composition uses these results when publishing
repository intelligence.

## Development

This is a Runtime workspace package.

```powershell
pnpm --filter @quillstone/communities-processes build
pnpm --filter @quillstone/communities-processes typecheck
```
