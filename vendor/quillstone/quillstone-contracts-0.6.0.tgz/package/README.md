# `@quillstone/contracts`

Shared harness-neutral contracts for Quillstone results, errors, warnings,
JSON values, generated command/MCP manifests, and validation evidence.

## Integration boundary

The package has no runtime dependencies. It exports frozen result-envelope
constructors (`success`, `degraded`, and `failure`), stable error and warning
categories, JSON validation, and typed manifest data consumed by the other
Quillstone packages. It does not execute commands, start MCP servers, access
repositories, or persist evidence.

## Development

This is a Runtime workspace package.

```powershell
pnpm --filter @quillstone/contracts build
pnpm --filter @quillstone/contracts typecheck
```

Generated manifests can be checked without rewriting them:

```powershell
pnpm --filter @quillstone/contracts check:manifests
```
