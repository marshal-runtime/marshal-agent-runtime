# `@quillstone/embedding-runtime`

Embedding providers for Quillstone search and indexing. The package implements
the `@quillstone/search` embedding contract with a local
Transformers.js/ONNX provider and an OpenAI-compatible HTTP provider.

## Configuration and constraints

The local provider defaults to a 384-dimension mxbai-embed-xsmall-v1 model
(approximately 96 MB, mean pooling, no query prompt). Configure `cacheDirectory`, `localFilesOnly`, device,
thread, batching, and CPU-fallback policy explicitly when the host needs
controlled model acquisition or execution. Windows `auto` selection currently
uses CPU. The compatibility default does not pin the upstream model revision;
set `revision` when reusable index identity must bind immutable model assets.

The remote provider requires a caller-supplied endpoint, model, token, and
dimensions. It enforces time and response-size bounds, rejects redirects, and
supports an injected HTTP transport. Sending source-derived text to a remote
endpoint is a host policy decision, not an automatic Runtime fallback.

## Gemini (Vertex AI `gemini-embedding-2`)

`GeminiEmbeddingProvider` (kind `vertex-gemini`) embeds through Vertex AI with
Application Default Credentials only (`GOOGLE_APPLICATION_CREDENTIALS`, gcloud
ADC, or the metadata server); no credential is read from config or logged.

- **Dimension.** MRL output defaults to 1536 (range 128 to 3072), half the
  native 3072-d footprint; 768 and 1536 are among Google's recommended widths.
  A different width is a different index identity.
- **Task formats.** The service ignores `task_type` for this model, so the
  prefix is inlined: documents are `title: none | text: <chunk>`, queries are
  `task: code retrieval | query: <q>`.
- **Identity.** Provider, model, revision, width, document format, query task
  and normalization feed the index identity digest, so 384-d local and Gemini
  indexes (or two Gemini widths) can never be read as one another.
- **Initial index.** `createGeminiBulkEmbedder` sends large corpora through
  Vertex batch prediction jobs (GCS JSONL in and out, half the online price),
  sharded, resumable from an atomic checkpoint, with poll backoff, a per-run
  spend ledger and a hard budget cap that refuses to start or stops the run.
  Corpora at or below `onlineThreshold` use the online API.
- **Incremental re-index.** Vectors are keyed by content hash plus model
  identity; only new or changed chunks are embedded.
- **Queries.** Online embedding with timeout, bounded retries, an LRU cache,
  in-flight coalescing and a circuit breaker. When Gemini is down, hybrid search
  returns `bm25_only` with the reason and semantic search fails with an error
  that says no other model was substituted.

Environment selection (used by `@quillstone/marshal-memory-bridge`):

| Variable | Meaning |
| --- | --- |
| `QUILLSTONE_EMBEDDING_PROVIDER=vertex-gemini` | select Gemini |
| `QUILLSTONE_GEMINI_PROJECT` (or `GOOGLE_CLOUD_PROJECT`) | Vertex project |
| `QUILLSTONE_GEMINI_BUDGET_USD` | required hard spend cap |
| `QUILLSTONE_GEMINI_LOCATION`, `_MODEL`, `_MODEL_REVISION`, `_DIMENSIONS`, `_QUERY_TASK`, `_QUERY_TIMEOUT_MS` (default 2000: a query without a vector by then falls back to keyword search), `_API_ENDPOINT` | optional overrides |
| `QUILLSTONE_GEMINI_BATCH_BUCKET`, `_BATCH_PREFIX` | GCS location for batch jobs; without a bucket everything is embedded online |
| `QUILLSTONE_GEMINI_ONLINE_THRESHOLD` | at or below this many chunks use the online API (default 1000) |

Prices (https://cloud.google.com/vertex-ai/generative-ai/pricing, verified
2026-10-19): text input $0.20 per 1M tokens online, $0.10 per 1M batch. The
model is labeled Preview. The Gemini tokenizer is not available offline, so
spend limits use chars/3 (conservative) and reports show chars/4 as well.

`createLocalCrossEncoderReranker()` scores query/passage pairs with a pinned
ms-marco-MiniLM-L-6-v2 q8 cross-encoder (about 23 MB). Its four files are
fetched only from huggingface.co at a fixed revision, verified by size and
SHA-256 before use, and loaded with `local_files_only`; set `allowDownload:
false` to require a pre-seeded cache. Calls are serialized and bounded to 64
query/passage pairs of 128 tokens.

`preflightEmbeddingRuntime()` inspects capability and cache readiness;
`installEmbeddingRuntime()` operates only on an explicitly dedicated cache
directory. Default Runtime code intelligence owns provider selection and
configuration.

## Development

This is a Runtime workspace package.

```powershell
pnpm --filter @quillstone/embedding-runtime build
pnpm --filter @quillstone/embedding-runtime typecheck
```
