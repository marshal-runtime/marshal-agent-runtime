# @quillstone/kind-health

Generic per-kind contracts and health for a typed graph. The caller supplies the data: the kind contracts, the kind schemas, the relation canonicalizer, the entries, and optional knowledge of sources (expected counts, source heads, search-store counts). The package has no dependency on the bridge.

- `KindContract`, `StampPolicies`, `RequiredEdge`: what a kind promises.
- `buildBrainHealth(entries, inputs, config)`: judges entries against the contracts and returns per-kind state and gaps (`GapCodes`, `GapTypes`, `KindStates`).
- `queryHealth`, `startBrainHealth`, `brainHealthAnswer`: narrowing, on-demand passes, and the tool answer.

`config.scopeField` names the entry field whose distinct values are counted as `brands` per kind (for example `brand_id`); omit it to count none.
