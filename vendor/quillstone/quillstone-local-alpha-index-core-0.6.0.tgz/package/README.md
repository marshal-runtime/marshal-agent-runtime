# `@quillstone/local-alpha-index-core`

Narrow local indexing core that composes repository scanning, resolution,
analysis enrichment, native persistence, publication, search, and embedding
lifecycle services.

## Public subpaths

The package intentionally has no root export. Import the smallest required
surface:

- `@quillstone/local-alpha-index-core/indexing` for bounded index requests and
  `rebuildLocalAlphaCodeIndex()`;
- `@quillstone/local-alpha-index-core/embeddings` for provider factories,
  generation adapters, checkpoints, and embedding lifecycle execution;
- `@quillstone/local-alpha-index-core/native-bridge` for
  `LocalAlphaNativeBridge` and `openLocalAlphaNativeBridge()`;
- `@quillstone/local-alpha-index-core/community-worker` for the community
  worker boundary.

Callers own repository authorization, roots, cancellation, and provider
configuration. Native candidates are published only through the persistence
and lifecycle contracts; partial work is not a successful index. Open native
bridges must be closed.

Default Runtime code intelligence uses this package through
`@quillstone/marshal-memory-bridge`.

## Development

This is a Runtime workspace package.

```powershell
pnpm --filter @quillstone/local-alpha-index-core build
pnpm --filter @quillstone/local-alpha-index-core typecheck
```
