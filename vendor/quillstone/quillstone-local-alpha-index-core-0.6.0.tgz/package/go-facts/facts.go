package main

import (
	"fmt"
	"go/ast"
	"go/token"
	"go/types"
	"path/filepath"
	"strings"

	"golang.org/x/tools/go/packages"
)

type span struct {
	StartLine   int `json:"startLine"`
	EndLine     int `json:"endLine"`
	StartColumn int `json:"startColumn"`
	EndColumn   int `json:"endColumn"`
}

type nodeFact struct {
	Key           string         `json:"key"`
	Table         string         `json:"table"`
	Name          string         `json:"name"`
	QualifiedName string         `json:"qualifiedName"`
	FilePath      string         `json:"filePath"`
	Language      string         `json:"language"`
	Span          span           `json:"span"`
	Discriminator string         `json:"discriminator"`
	Properties    map[string]any `json:"properties"`
}

type relationFact struct {
	From       string  `json:"from"`
	To         string  `json:"to"`
	Type       string  `json:"type"`
	Confidence float64 `json:"confidence"`
	Reason     string  `json:"reason"`
}

var tables = map[string]string{
	"function": "Function", "method": "Method", "struct": "Struct", "interface": "Interface",
	"type": "TypeAlias", "variable": "Variable", "constant": "Const", "field": "Property",
}

type extractor struct {
	root       string
	fset       *token.FileSet
	nodes      []nodeFact
	relations  []relationFact
	keys       map[types.Object]string
	byPosition map[string]string
	typeKeys   map[string]string
	seen       map[string]bool
	files      map[string]bool
}

func newExtractor(root string, fset *token.FileSet) *extractor {
	return &extractor{
		root: root, fset: fset,
		keys: map[types.Object]string{}, byPosition: map[string]string{}, typeKeys: map[string]string{},
		seen: map[string]bool{}, files: map[string]bool{},
	}
}

func (e *extractor) relative(pos token.Pos) (string, token.Position) {
	position := e.fset.Position(pos)
	rel, err := filepath.Rel(e.root, position.Filename)
	if err != nil {
		rel = position.Filename
	}
	return filepath.ToSlash(rel), position
}

func fileKey(path string) string { return "file:" + path }

func (e *extractor) relate(from, to, kind string) {
	if from == "" || to == "" || from == to {
		return
	}
	id := from + "\x00" + to + "\x00" + kind
	if e.seen[id] {
		return
	}
	e.seen[id] = true
	e.relations = append(e.relations, relationFact{From: from, To: to, Type: kind, Confidence: 1, Reason: "go-types"})
}

func docText(groups ...*ast.CommentGroup) string {
	for _, group := range groups {
		if group != nil {
			if text := strings.TrimSpace(group.Text()); text != "" {
				return text
			}
		}
	}
	return ""
}

// declare records a declaration once per source position; test variants of
// a package re-type-check the same files and must map to the same node.
func (e *extractor) declare(obj types.Object, kind, container string, start, end token.Pos, doc string) string {
	if obj == nil || obj.Name() == "_" {
		return ""
	}
	if key, ok := e.keys[obj]; ok {
		return key
	}
	file, from := e.relative(start)
	_, to := e.relative(end)
	_, at := e.relative(obj.Pos())
	position := fmt.Sprintf("%s:%d", file, at.Offset)
	if key, ok := e.byPosition[position]; ok {
		e.keys[obj] = key
		return key
	}
	key := fmt.Sprintf("go:%s:%s@%d:%d", file, kind, at.Line, at.Column)
	e.byPosition[position] = key
	e.keys[obj] = key
	qualified := obj.Name()
	if container != "" {
		qualified = container + "." + obj.Name()
	}
	properties := map[string]any{
		"kind": kind, "exported": obj.Exported(), "resolver": "go-types",
		"signatures": []string{types.ObjectString(obj, types.RelativeTo(obj.Pkg()))},
	}
	if obj.Pkg() != nil {
		properties["package"] = obj.Pkg().Path()
	}
	if doc != "" {
		properties["documentation"] = doc
	}
	e.nodes = append(e.nodes, nodeFact{
		Key: key, Table: tables[kind], Name: obj.Name(), QualifiedName: qualified, FilePath: file, Language: "Go",
		Span:          span{StartLine: from.Line, EndLine: to.Line, StartColumn: from.Column, EndColumn: to.Column},
		Discriminator: fmt.Sprintf("%s@%d:%d", kind, at.Line, at.Column),
		Properties:    properties,
	})
	return key
}

func receiverName(fn *ast.FuncDecl) string {
	if fn.Recv == nil || len(fn.Recv.List) == 0 {
		return ""
	}
	expr := fn.Recv.List[0].Type
	for {
		switch typed := expr.(type) {
		case *ast.StarExpr:
			expr = typed.X
		case *ast.IndexExpr:
			expr = typed.X
		case *ast.IndexListExpr:
			expr = typed.X
		case *ast.Ident:
			return typed.Name
		default:
			return ""
		}
	}
}

func (e *extractor) declareFile(pkg *packages.Package, file *ast.File) {
	path, _ := e.relative(file.Pos())
	e.files[path] = true
	owner := fileKey(path)
	for _, decl := range file.Decls {
		switch typed := decl.(type) {
		case *ast.FuncDecl:
			kind := "function"
			if typed.Recv != nil {
				kind = "method"
			}
			key := e.declare(pkg.TypesInfo.Defs[typed.Name], kind, receiverName(typed), typed.Pos(), typed.End(), docText(typed.Doc))
			e.relate(owner, key, "CONTAINS")
		case *ast.GenDecl:
			for _, spec := range typed.Specs {
				switch s := spec.(type) {
				case *ast.TypeSpec:
					kind := "type"
					if _, ok := s.Type.(*ast.InterfaceType); ok {
						kind = "interface"
					} else if _, ok := s.Type.(*ast.StructType); ok {
						kind = "struct"
					}
					obj := pkg.TypesInfo.Defs[s.Name]
					key := e.declare(obj, kind, "", s.Pos(), s.End(), docText(s.Doc, typed.Doc))
					e.relate(owner, key, "CONTAINS")
					if obj != nil && obj.Pkg() != nil {
						e.typeKeys[obj.Pkg().Path()+"."+obj.Name()] = key
					}
					e.declareMembers(pkg, s, key)
				case *ast.ValueSpec:
					kind := "variable"
					if typed.Tok == token.CONST {
						kind = "constant"
					}
					for _, name := range s.Names {
						key := e.declare(pkg.TypesInfo.Defs[name], kind, "", s.Pos(), s.End(), docText(s.Doc, typed.Doc))
						e.relate(owner, key, "CONTAINS")
					}
				}
			}
		}
	}
}

func (e *extractor) declareMembers(pkg *packages.Package, spec *ast.TypeSpec, ownerKey string) {
	owner := spec.Name.Name
	switch typed := spec.Type.(type) {
	case *ast.StructType:
		for _, field := range typed.Fields.List {
			for _, name := range field.Names {
				key := e.declare(pkg.TypesInfo.Defs[name], "field", owner, field.Pos(), field.End(), docText(field.Doc, field.Comment))
				e.relate(ownerKey, key, "HAS_PROPERTY")
			}
		}
	case *ast.InterfaceType:
		for _, method := range typed.Methods.List {
			for _, name := range method.Names {
				key := e.declare(pkg.TypesInfo.Defs[name], "method", owner, method.Pos(), method.End(), docText(method.Doc, method.Comment))
				e.relate(ownerKey, key, "HAS_METHOD")
			}
		}
	}
}

// linkMethods adds HAS_METHOD from each in-repo receiver type to its methods.
func (e *extractor) linkMethods(pkg *packages.Package, file *ast.File) {
	for _, decl := range file.Decls {
		fn, ok := decl.(*ast.FuncDecl)
		if !ok || fn.Recv == nil {
			continue
		}
		obj := pkg.TypesInfo.Defs[fn.Name]
		if obj == nil || obj.Pkg() == nil {
			continue
		}
		if typeKey, ok := e.typeKeys[obj.Pkg().Path()+"."+receiverName(fn)]; ok {
			e.relate(typeKey, e.keys[obj], "HAS_METHOD")
		}
	}
}
