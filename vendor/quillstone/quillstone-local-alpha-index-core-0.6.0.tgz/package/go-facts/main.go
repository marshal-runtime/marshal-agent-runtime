// Command go-facts emits go/types-resolved declarations and relations for a
// Go repository as Quillstone parser facts (JSON on stdout).
package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"go/types"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"

	"golang.org/x/tools/go/packages"
)

type output struct {
	Nodes        []nodeFact     `json:"nodes"`
	Relations    []relationFact `json:"relations"`
	CoveredFiles []string       `json:"coveredFiles"`
	Errors       []string       `json:"errors"`
	ElapsedMs    int64          `json:"elapsedMs"`
}

func main() {
	root := flag.String("root", ".", "repository root used for relative paths")
	dir := flag.String("dir", "", "module or workspace directory to load from (defaults to root)")
	tests := flag.Bool("tests", true, "include test files")
	flag.Parse()
	started := time.Now()
	absRoot, err := filepath.Abs(*root)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	patterns := flag.Args()
	if len(patterns) == 0 {
		patterns = []string{"./..."}
	}
	loadDir := absRoot
	if *dir != "" {
		loadDir = *dir
	}
	pkgs, err := packages.Load(&packages.Config{
		Mode:  packages.NeedName | packages.NeedFiles | packages.NeedSyntax | packages.NeedTypes | packages.NeedTypesInfo | packages.NeedImports | packages.NeedDeps,
		Dir:   loadDir,
		Tests: *tests,
	}, patterns...)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	if len(pkgs) == 0 {
		fmt.Fprintln(os.Stderr, "no packages matched", patterns)
		os.Exit(1)
	}
	e := newExtractor(absRoot, pkgs[0].Fset)
	var errors []string
	packages.Visit(pkgs, nil, func(pkg *packages.Package) {
		for _, message := range pkg.Errors {
			if len(errors) < 200 {
				errors = append(errors, message.Error())
			}
		}
	})
	inRoot := func(pkg *packages.Package, index int) bool {
		return strings.HasPrefix(pkg.Fset.Position(pkg.Syntax[index].Pos()).Filename, absRoot+string(filepath.Separator))
	}
	// Repository modules outside go.work (generated proto/db models reached
	// through replace directives) load only as dependencies; they are still
	// repository code, so every loaded package with files under the root counts.
	var roots []*packages.Package
	packages.Visit(pkgs, nil, func(pkg *packages.Package) {
		if pkg.TypesInfo == nil {
			return
		}
		for index := range pkg.Syntax {
			if inRoot(pkg, index) {
				roots = append(roots, pkg)
				return
			}
		}
	})
	for _, pkg := range roots {
		for index, file := range pkg.Syntax {
			if inRoot(pkg, index) {
				e.declareFile(pkg, file)
			}
		}
	}
	visited := map[string]bool{}
	for _, pkg := range roots {
		for index, file := range pkg.Syntax {
			name := pkg.Fset.Position(file.Pos()).Filename
			if !inRoot(pkg, index) || visited[name+"|"+pkg.ID] {
				continue
			}
			visited[name+"|"+pkg.ID] = true
			e.linkMethods(pkg, file)
			e.referencesFile(pkg, file)
		}
	}
	var named []*types.TypeName
	for obj := range e.keys {
		if typeName, ok := obj.(*types.TypeName); ok && e.keys[obj] != "" {
			named = append(named, typeName)
		}
	}
	sort.Slice(named, func(i, j int) bool { return e.keys[named[i]] < e.keys[named[j]] })
	e.implementsEdges(named)
	covered := make([]string, 0, len(e.files))
	for path := range e.files {
		covered = append(covered, path)
	}
	sort.Strings(covered)
	result := output{Nodes: e.nodes, Relations: e.relations, CoveredFiles: covered, Errors: errors, ElapsedMs: time.Since(started).Milliseconds()}
	if err := json.NewEncoder(os.Stdout).Encode(result); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
