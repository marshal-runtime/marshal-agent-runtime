package main

import (
	"go/ast"
	"go/types"

	"golang.org/x/tools/go/packages"
)

func referenceType(stack []ast.Node, ident *ast.Ident, obj types.Object) string {
	if _, ok := obj.(*types.TypeName); ok {
		return "USES"
	}
	var node ast.Node = ident
	for i := len(stack) - 1; i >= 0; i-- {
		switch parent := stack[i].(type) {
		case *ast.SelectorExpr:
			if parent.Sel == node {
				node = parent
				continue
			}
		case *ast.IndexExpr:
			if parent.X == node {
				node = parent
				continue
			}
		case *ast.IndexListExpr:
			if parent.X == node {
				node = parent
				continue
			}
		case *ast.CallExpr:
			if parent.Fun == node {
				return "CALLS"
			}
		}
		break
	}
	return "ACCESSES"
}

func (e *extractor) ownerOf(pkg *packages.Package, node ast.Node) string {
	var obj types.Object
	switch typed := node.(type) {
	case *ast.FuncDecl:
		obj = pkg.TypesInfo.Defs[typed.Name]
	case *ast.TypeSpec:
		obj = pkg.TypesInfo.Defs[typed.Name]
	case *ast.ValueSpec:
		if len(typed.Names) > 0 {
			obj = pkg.TypesInfo.Defs[typed.Names[0]]
		}
	}
	if obj == nil {
		return ""
	}
	return e.keys[obj]
}

func origin(obj types.Object) types.Object {
	if fn, ok := obj.(*types.Func); ok && fn.Origin() != nil {
		return fn.Origin()
	}
	if variable, ok := obj.(*types.Var); ok && variable.Origin() != nil {
		return variable.Origin()
	}
	return obj
}

// referencesFile attributes every resolved identifier use to its innermost
// enclosing declaration (or the file for imports and package clauses).
func (e *extractor) referencesFile(pkg *packages.Package, file *ast.File) {
	path, _ := e.relative(file.Pos())
	fallback := fileKey(path)
	var stack []ast.Node
	var owners []string
	ast.Inspect(file, func(node ast.Node) bool {
		if node == nil {
			last := stack[len(stack)-1]
			stack = stack[:len(stack)-1]
			if e.ownerOf(pkg, last) != "" {
				owners = owners[:len(owners)-1]
			}
			return true
		}
		if owner := e.ownerOf(pkg, node); owner != "" {
			owners = append(owners, owner)
		}
		stack = append(stack, node)
		ident, ok := node.(*ast.Ident)
		if !ok {
			return true
		}
		obj := pkg.TypesInfo.Uses[ident]
		if obj == nil {
			return true
		}
		target, ok := e.keys[origin(obj)]
		if !ok {
			return true
		}
		from := fallback
		if len(owners) > 0 {
			from = owners[len(owners)-1]
		}
		e.relate(from, target, referenceType(stack[:len(stack)-1], ident, obj))
		return true
	})
}

// implementsEdges links in-repo concrete types to the in-repo interfaces they
// satisfy, and each implementing method to the interface method it fulfils.
func (e *extractor) implementsEdges(named []*types.TypeName) {
	var interfaces []*types.TypeName
	for _, obj := range named {
		if types.IsInterface(obj.Type()) {
			interfaces = append(interfaces, obj)
		}
	}
	for _, obj := range named {
		if types.IsInterface(obj.Type()) {
			continue
		}
		for _, iface := range interfaces {
			underlying, ok := iface.Type().Underlying().(*types.Interface)
			if !ok || underlying.NumMethods() == 0 {
				continue
			}
			var receiver types.Type
			if types.Implements(obj.Type(), underlying) {
				receiver = obj.Type()
			} else if types.Implements(types.NewPointer(obj.Type()), underlying) {
				receiver = types.NewPointer(obj.Type())
			} else {
				continue
			}
			e.relate(e.keys[obj], e.keys[iface], "IMPLEMENTS")
			for index := 0; index < underlying.NumMethods(); index++ {
				wanted := underlying.Method(index)
				found, _, _ := types.LookupFieldOrMethod(receiver, true, wanted.Pkg(), wanted.Name())
				if method, ok := found.(*types.Func); ok {
					e.relate(e.keys[origin(method)], e.keys[wanted], "METHOD_IMPLEMENTS")
				}
			}
		}
	}
}
