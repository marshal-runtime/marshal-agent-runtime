# `@quillstone/marshal-memory-bridge`

Versioned service bridge that combines a Quillstone code index with bounded
Marshal-owned code/knowledge projections.

## Integration boundary

`createMarshalMemoryBridge()` accepts absolute code, projection, and data roots
plus stable Marshal profile and project identities. It exposes bounded document
mutation, rebuild, search, context, impact, change detection, status, and
`close()` operations. `createWorktreeAwareMarshalMemoryBridge()` shares the
repository index while preserving worktree-aware reads.

The projection is derived data: canonical memory remains owned by Marshal.
Profile, project, and projection identities define an isolated namespace.
Incremental projection mutation requires an active code index in
`code-memory` mode; `memory-only` mode creates an isolated memory index.

Omitting `embeddingProvider` selects the supported local provider, or the
Vertex `gemini-embedding-2` provider when `QUILLSTONE_EMBEDDING_PROVIDER=vertex-gemini`
(see `@quillstone/embedding-runtime` for the variables; a USD budget cap is
mandatory). `pnpm run gemini:dry-run -- --code-root <repo> [--dimensions 1536]`
runs the real chunking pipeline and prints chunk, token and cost totals without
contacting Google, followed by a table per node label (Function, Method, Class,
Const, Property, files by extension, document blocks, and the labels that are not
embedded) with nodes, chunks, tokens and batch cost. `--entries-out <file>` saves
the counts of one part; `--merge <file>...` combines parts of a corpus. Passing
With the Gemini provider the corpus follows the embedding units contract
(`v6-units`, `@quillstone/search` `units.ts`): code vectors are capped at about 2k
tokens and split only along statements, classes are one summary vector of member
signatures, every vector carries a uniform short header plus a one-hop line, and
nodes can have several vectors (memory, brand, code file summary) with search
taking the best one per node. Tickets, pull requests, meetings, memories and
brand nodes have entity units; people have none. A flagged Flash-class summarizer
(`QUILLSTONE_GENERATED_SUMMARIES=1`, own USD cap) adds descriptions. The dry run
reports tokens and USD per node type at the batch and online prices, the
generated-summary cost, the cost per 1M searches and the USD 300 cap check. The
local 384-d provider keeps the v5 chunking. Design and counts:
`docs/EMBEDDING-UNITS.md`.
`null` disables vectors while retaining BM25 and graph behavior. Callers that
provide a remote provider own endpoint authorization and data policy. Always
close the bridge to release native and owned embedding resources.

`createWorktreeAwareMarshalMemoryBridge()` adds a final rerank stage to
`search()`: the top 20 fused code hits are reordered by a local cross-encoder
(see `@quillstone/embedding-runtime`), memory hits keep their slots, and each
reordered hit gains a `rerank` explanation source. BM25-only
and memory-only searches skip it. A reranker failure keeps the fused order and
marks the result `degraded` with a reason. Pass `reranker: null` to disable it
or a `MemoryBridgeReranker` to replace it; it is off by default when a custom
`embeddingProvider` is supplied. Code hits carry a bounded `summary`
(documentation, then signature).

Target resolution by bare `name` prefers the single node whose whole qualified
name equals it (a top-level `record` over `Harness.record`); remaining
ambiguity is an error. Base snapshots and worktree overlays carry a hidden
`.quillstone-git-visible-tree` marker so the scanner keeps git-tracked
directories with generic output names (`build`, `cache`, `out`, `target`).

Default Runtime exposes this bridge through
`@marshal/agent-runtime-code-intelligence` as a bounded code/knowledge
projection bridge rather than as a direct host API. Other optional consumers
may use the same generic bridge.

## Development

This is a Runtime workspace package.

```powershell
pnpm --filter @quillstone/marshal-memory-bridge build
pnpm --filter @quillstone/marshal-memory-bridge typecheck
```
