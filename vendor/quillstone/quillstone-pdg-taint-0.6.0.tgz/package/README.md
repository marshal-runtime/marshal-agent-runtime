# `@quillstone/pdg-taint`

Program-dependence and taint analysis for Quillstone graph intelligence.

## Integration boundary

`buildPdg()` derives basic blocks, control-flow/control-dependence relations,
reaching definitions, and optional policy-driven taint findings from normalized
function inputs. `PdgService` provides bounded query, explain, impact, and trace
operations, and adapters expose those operations to the higher-level analysis
service.

PDG construction currently supports JavaScript, JSX, TypeScript, and TSX
language identifiers. Disabled features, unsupported languages, iteration
limits, and truncated taint paths are represented through capability state and
diagnostics rather than an empty successful result. Repository scanning,
parser extraction, policy approval, and persistence remain outside this
package.

The default Runtime indexing composition treats PDG/taint as an optional
analysis layer.

## Development

This is a Runtime workspace package.

```powershell
pnpm --filter @quillstone/pdg-taint build
pnpm --filter @quillstone/pdg-taint typecheck
```
