# `@quillstone/repository-registry-config`

Strict configuration, repository identity, branch-slot, registry, storage
policy, and staleness primitives for Quillstone.

## Integration boundary

Configuration resolution is schema-driven and defaults to built-in,
environment, repository, then CLI precedence. Fields can restrict their allowed
sources; secret fields cannot be accepted from repository configuration.

Repository identities normalize platform path semantics without granting
filesystem authority. `RepositoryRegistryStore` uses a caller-supplied atomic
storage port and compare-and-replace version to commit registry updates.
Callers also supply product-native locations through the storage policy.

The default Runtime code-intelligence composition uses these contracts to keep
repository selection and index locations explicit and bounded.

## Development

This is a Runtime workspace package.

```powershell
pnpm --filter @quillstone/repository-registry-config build
pnpm --filter @quillstone/repository-registry-config typecheck
```
