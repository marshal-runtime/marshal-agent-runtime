# `@quillstone/resolution-index-pipeline`

Bounded graph normalization, reference resolution, domain extraction, staged
index execution, lifecycle receipts, and atomic candidate-publication contracts
for Quillstone indexing.

The package defines the pipeline and its public callback/controller boundaries;
scanner, native storage, registry, and embedding implementations are injected by
the composing index service. Default Runtime code intelligence reaches this
package through the local alpha index and memory bridge.

## Development

This is a Runtime workspace package.

```powershell
pnpm --filter @quillstone/resolution-index-pipeline build
pnpm --filter @quillstone/resolution-index-pipeline typecheck
```

## Source coordinates

Normalized graph spans use one-based lines and columns. Parser adapters must
convert zero-based parser coordinates before graph normalization. Native graph
rows, analysis readback, search documents, and embedding line ranges preserve
the same one-based contract.

## Qualified reference safety

References bound to an imported module resolve only through matching import
bindings. A qualified reference without a resolved receiver or import binding
does not fall back to a same-file leaf or global symbol match.

## Public data boundary

All exported operations snapshot public records, unions, dictionaries, and arrays
before using them. The boundary accepts plain same-realm or cross-realm records
and arrays, rejects proxies, accessors, sparse arrays, inherited fields, symbol
keys, array expando properties, forged prototype shapes, and custom prototypes,
and retains no caller-owned DTO collections. Cross-realm roots are accepted only
when their native constructor points back to the exact realm prototype; accepted
values are always copied into package-owned canonical records and dense arrays.

The ten formerly Promise-capable callback surfaces do not accept raw functions.
Use `pipelineStageCallbacks.synchronous()` or
`candidatePublicationCallbacks.synchronous()` for synchronous integrations.
These factories return package-owned wrapper functions registered in private
`WeakMap`s. Async functions and callbacks that return a Promise reject; the
opaque wrapper types are not directly callable by consumers, and the package
never assimilates, calls, or awaits that Promise or any caller thenable.

Asynchronous integrations use `pipelineStageCallbacks.controller()` or
`candidatePublicationCallbacks.controller()`. The package invokes only the
controller's branded wrapper. External work receives a frozen null-prototype
request through `observe()` or `take()`, performs its work independently, and
settles the opaque token through the operation-specific controller method.
Controller failure is represented by an always-fulfilled package-owned internal
envelope, so controller rejection cannot create an unhandled rejected Promise.

Each token is one-shot and privately bound before exposure to its controller,
operation, request identifier, run, repository, branch, plan digest, candidate
generation, and publication fence as applicable. Forged, copied, proxied,
cross-controller, cross-operation, late, and duplicate tokens reject before
settlement data is inspected. The first valid settlement attempt consumes the
token even when its value is invalid. Requests, bindings, tokens, controller
snapshots, and controller records are frozen null-prototype values.

Pending observer and undelivered request queues are prototype-free and bounded
at 1,024 entries. Package-owned promises carry an immutable own constructor, so
callback-side poisoning of the global `Promise`, `Promise.prototype.then`,
`Promise.prototype.constructor`, or `Promise[Symbol.species]` cannot redirect
package settlement. Publication failures remain deterministic: failures before
CAS follow cleanup rules, while an invoked CAS or later readback failure remains
recovery-required.

Proxy detection intentionally uses Node.js `util.types.isProxy`. This package's
public boundary is therefore Node-only; a browser runtime needs a separate
trusted adapter rather than a weaker proxy-detection fallback.

`MAX_PIPELINE_EVENT_ID_COUNT` bounds completion-event declarations and every
per-stage receipt `eventIds` list; `MAX_LIFECYCLE_EVENT_ID_COUNT` is its lifecycle
compatibility alias. Stage `produces` route/artifact names intentionally use the
larger global JSON item cap because repository artifact sets are data-volume
bounded rather than phase-vocabulary bounded.
