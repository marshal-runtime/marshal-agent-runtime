# `@quillstone/scanner-parsers`

Bounded repository scanning and Tree-sitter parser providers for Quillstone
indexing.

## Integration boundary

`scanRepository()` works through caller-supplied filesystem and content-hash
ports, repository-relative slash-delimited paths, layered ignore rules,
cooperative cancellation, file-size limits, and bounded concurrency. The
default parser registry covers TypeScript/TSX, Rust, C#, Go, and Python.
JavaScript and other declared inputs remain deferred or unsupported at this
generic scanner boundary unless a composing pipeline supplies a separate
strategy.

Git-tracked directories with generic output names (`build`, `cache`, `out`,
`target`) are kept when the caller passes `trackedSourceDirectories`. When the
pinned TypeScript grammar rejects syntax that `tsc` accepts (`&` in JSX text,
`export type *`, `import("x").T` types), the provider reparses after
same-length repairs and keeps the result only if it has fewer errors.

Parser results include diagnostics and cache identities. Worker timeout
reporting does not terminate native parser work; callers must continue to own
cancellation and worker lifecycle. The package does not choose a repository,
read outside its supplied scanner port, or publish an index.

Default Runtime code intelligence uses these providers through the local alpha
indexing composition.

## Development

This is a Runtime workspace package with pinned Tree-sitter dependencies.

```powershell
pnpm --filter @quillstone/scanner-parsers build
pnpm --filter @quillstone/scanner-parsers typecheck
```
