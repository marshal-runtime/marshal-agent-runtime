# `@quillstone/search`

Search contracts and services for Quillstone BM25, semantic, and hybrid
retrieval.

## Integration boundary

`SearchService` operates on an injected `SearchBackend` and optional embedding
provider. It normalizes and escapes text queries, validates bounded limits,
performs reciprocal-rank fusion, groups results by process, and returns explicit
capability, completeness, staleness, and degradation metadata.

Semantic and hybrid queries require the query provider identity and dimensions
to match the provider recorded in the active index. A mismatch degrades or
rejects semantic behavior rather than silently reusing incompatible vectors.
The package also exports deterministic embedding-corpus planning and generation
helpers; model loading and native persistence live in other packages.

Default Runtime code intelligence supplies the native backend and selected
embedding provider through the local alpha composition.

## Development

This is a Runtime workspace package.

```powershell
pnpm --filter @quillstone/search build
pnpm --filter @quillstone/search typecheck
```
