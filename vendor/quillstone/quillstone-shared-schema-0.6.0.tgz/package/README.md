# `@quillstone/shared-schema`

Frozen graph, relation, embedding, storage, metadata, and source-coordinate
schema contracts shared across Quillstone packages.

## Integration boundary

Exports include canonical node and relation vocabularies, the separate
`CodeEmbedding` table shape, schema and source-coordinate versions, native FTS
and vector defaults, storage metadata requirements, and rebuild rules for
breaking changes. Memory/evidence nodes and their derived relation types extend
the code graph without making this package the canonical memory authority.

This package defines data compatibility only. It does not open a database,
perform migrations, scan repositories, or publish candidates. Default Runtime
code intelligence relies on these constants through the native adapter, search,
pipeline, and bridge packages.

## Development

This is a Runtime workspace package.

```powershell
pnpm --filter @quillstone/shared-schema build
pnpm --filter @quillstone/shared-schema typecheck
```
