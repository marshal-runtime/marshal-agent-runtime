# @quillstone/spanner-storage

The Cloud Spanner storage engine of Quillstone: schema, reader and writer. Ported from `zyg-agents` `src/quillstone/storage/**` (see `SOURCE.md` for the exact commit).

## Running the ports on the far side of a socket

A process without Google credentials builds its ports with `createRemotePorts(transport, { storeId, repositoryId })`; a trusted broker answers each request with `servePortRequest(server, request)`, where `server` is `{ readerFor, writer, loaded }` built from the real factories:

```ts
// broker
const server: PortServer = {
  readerFor: ({ storeId, repositoryId }) => createStoreReader({ database, storeId, repositoryId }),
  writer: new SpannerStoreWriter({ database }),
  loaded: { isStoreLoaded: async (storeId) => /* a Stores row query */ true },
};
// brand process
const ports = createRemotePorts(sendOverSocket, { storeId, repositoryId });
// ports.reader, ports.writer and ports.loaded are the injected store ports
```

Keep one reader per store in the broker (its caches matter); `servePortRequest` calls `readerFor` on every request.

### Wire format (`PORT_WIRE_VERSION = 1`)

`PortTransport = (request: PortRequest) => Promise<PortResponse>`; both are JSON-safe (`JSON.parse(JSON.stringify(x))` is equal to `x`).

- `PortRequest = { version: 1, storeId, repositoryId, call }` where `call` is `{ op, ...arguments }`. Read ops: `readKnowledgePublication`, `loadSearch`, `hydrateKnowledgeNodes`, `readVisibleEntityCount`, `queryNodes`, `resolveKnowledgeTarget`, `readKnowledgeFrontier`, `status`, and the search-backend ops `describeIndex`, `searchFts`, `searchVector`, `repairFts`. Write ops: `applyDelta`, `orphanedNodeIds`, `isStoreLoaded`. The argument and result types are the unchanged `StoreReadPort` / `StoreDelta` types; `PortResults` lists each op's result.
- `PortResponse = { ok: true, value } | { ok: false, error: { name, message, code? } }`. A port failure is an `ok: false` response, not a transport error; the client rebuilds an `Error` with the same name, message and code.
- Differences from the in-process ports: the opaque `context` / `selector` arguments are not sent (the Spanner reader ignores them); the `onShortfall` callback of an FTS request is replaced by `shortfalls: string[]` in the answer, which the client replays; `loadSearch` answers only `{ generation }` and the client's backend sends `describeIndex` / `searchFts` / `searchVector` / `repairFts` calls; `undefined` travels as `null`.
- `loopbackTransport(server)` is an in-process transport that does the JSON round trip; use it in tests.

## Schema

`applySchema(database, { ann?, partitionedSearchIndex?, columnsOnly?, dryRun? })` creates the base tables, indexes and property graph that are missing (not with `columnsOnly`), then adds the columns of `ADDED_COLUMNS` that an older database lacks, each with `ADD COLUMN IF NOT EXISTS`, nullable, with no default and no index, so the ALTER changes metadata only. It is idempotent, reports the schema operation's name and duration, and no serving process calls it: one operator runs `node dist/storage/spanner/apply-schema.js --database projects/P/instances/I/databases/D [--columns-only]`, which lists the statements, and adds `--apply` to run them. On a serving database use `--columns-only`. The vector (ANN) index builds for tens of minutes, so it is created only with `ann: true`; the partitioned search index separately requires `partitionedSearchIndex: true`. Defaults: 500 leaves built, 160 searched (`QUILLSTONE_SPANNER_ANN=1` turns ANN reads on, `QUILLSTONE_SPANNER_ANN_LEAVES` overrides the 160), filter columns stored in the vector index, keyword search returns ids and matched-term counts rather than document text.

### Store-partitioned lexical candidates (opt-in)

`NodesTextByStore` is an additive search index: the same `text_tokens`, `stem_tokens` and stored `kind`, `record_type`, `access` as `NodesText`, partitioned by `store_id`. It is deliberately absent from `BRAIN_DDL`. The existing `applySchema` missing-object mechanism adds it only with the explicit operator option `partitionedSearchIndex: true`, without changing the `brain-spanner-v1` store contract. Default, `ann: true` and `columnsOnly` modes never build it. The query-routing environment setting cannot enable schema application. Building an index on a loaded database is a backfill, not a metadata-only change.

The operator first previews `node dist/storage/spanner/apply-schema.js --database projects/P/instances/I/databases/D --partitioned-search-index`, reviews the reported statements, and adds `--apply` to execute. Both flags are required to start the backfill. `--partitioned-search-index` and `--columns-only` are exclusive. On a loaded database submit only the reviewed index DDL if the schema preview includes unrelated missing objects; never invoke this command from serving startup or a release hook.

`QUILLSTONE_SPANNER_PARTITIONED_SEARCH=1` selects the new index for lexical candidate reads. Unset, `0` and other values keep the old route. Both routes use `FORCE_INDEX`, so merely creating the new index cannot switch the default-off candidate query. Only the index changes: store/access/ID filters, score ordering, candidate limits and BM25 reranking stay the same. The setting is read when the provider creates the store reader; enable it only after the index is ready, and restart/recreate readers to change it. An enabled route with a missing index fails visibly rather than silently changing routes. Keep `NodesText` until output/ranking and production profiles have been compared. Before eventually dropping it, remove its default-route hint and its `BRAIN_DDL` entry in a follow-up; otherwise old readers would fail and `applySchema` would recreate it.

The opt-in emulator test creates an isolated database, applies the new index to the prior schema, and runs both reader routes against the same fixture:

```sh
cd packages/spanner-storage
SPANNER_EMULATOR_HOST=127.0.0.1:19010 QUILLSTONE_SPANNER_EMULATOR_TEST=1 pnpm exec vitest run src/storage/spanner/read/__tests__/lexical-emulator.test.ts
```

Use an emulator endpoint only (the test requires a loopback address); for Mac development, run the emulator on Coder and forward its port. Emulator timing and plans do not estimate production performance. Production rollout still compares the same real parameter sets, ordered IDs, scores, PROFILE CPU and rows on both indexes at the same read timestamp before enabling the setting.

### Entity source digests

`Chunks.source_digest` holds, for a chunk of an entity node, the content digest of the node it was embedded from; every other chunk leaves it NULL. The writer and the entity vector pass name the column only after a probe of INFORMATION_SCHEMA finds it (rechecked every 5 minutes until it does; a probe that fails is logged and counts as absent until the next look), so this version runs on a database without it, and an earlier version runs on a database with it. Once the column exists, the pass embeds an entity that has no chunk, or that is stale: it has a content digest and a chunk with a digest, and no chunk carries its content digest. A NULL digest means "not known": a node whose chunks are all NULL is never stale, so a late or partial backfill re-embeds nothing. The pass replaces the stale chunks and tags the new ones, so a changed entity is embedded once and then left alone.

`node dist/storage/spanner/backfill-source-digest.js --database projects/P/instances/I/databases/D [--store ID]... [--batch-rows 500] [--max-batches N] [--pause-ms N] [--tag TAG] [--bridge-from DIR] [--apply --ddl-done-at ISO]` tags the untagged chunks of entity nodes once, without re-embedding. Per node it compares the stored chunks with the chunks the entity vector pass would embed now (the bridge's `expectedEntityChunks`, under the store's published embedding identity and provider kind): with the same count and the same `content_hash` at each chunk index, all its chunks get the node's content digest; otherwise all get `UNVERIFIED_SOURCE_DIGEST`, which never equals a content digest, so the pass re-embeds that node once within its caps. A node whose properties rebuild no document stays untagged. Without `--apply` it counts the matching, mismatching and unreadable nodes and rows, the chunks and characters the mismatches will embed, and the mutations and bytes; with it, it tags them in transactions of at most `--batch-rows` rows (one node's chunks never split), each re-reading and re-comparing its nodes, with a pause between. It leaves code chunks and the store generation alone. The command loads `@quillstone/marshal-memory-bridge`, an optional peer: where this package cannot resolve it (a host that vendors the bridge beside it, such as zyg-agents' `vendor/runtime`), pass `--bridge-from DIR`, a directory whose `node_modules` (at or above it) holds the bridge. The command runs when started through a `node_modules` link too.

Order on a serving database: apply the column, wait at least 5 minutes (`MIN_APPLY_DELAY_MS`, the probe's recheck interval) so every running writer and pass has seen it, and pass the DDL's finish time as `--ddl-done-at`; the apply refuses to start sooner. After the apply, run the dry run again: it must report 0 untagged rows (unreadable nodes excepted).

## Not included

Zyg Brain serving machinery (RAM lanes, vector prefix, segment mirror and its sink, slot hand-off, serving env, the nightly communities report) and the integration harness that needs a real Spanner database.
